# Bitcoin Sandbox submission kit

Open DEVPOST.md for form copy and media/ for the thumbnail/gallery.

The complete source snapshot is in source/. From that directory, run `./start.sh sandbox` on Linux x64 with Node22 and pnpm12.16.1, then open http://127.0.0.1:4404. See source/docs/sandbox/SETUP.md for Docker and hosting.

evidence/ contains builder-controlled regtest and browser acceptance. Coins have no monetary value. SHA256SUMS checks archive integrity; it is not an independent security attestation.

The user renders/exports and uploads the final demo, then enters its YouTube/Vimeo URL in Devpost. No submission confirmation is implied.
